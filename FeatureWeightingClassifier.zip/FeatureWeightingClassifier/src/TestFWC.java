import core.Features;
import core.FwcClassifier;
import core.FWCModel;
import core.Utilities;

import java.io.IOException;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class TestFWC {

    public static void printUsage(){
        System.out.println("\nUsage: Please pass parameters in the following order (FWC.jar must be in the classpath)\n" +
                "Training: -train <trainingFile> [ modelFileName ]\n" +
                "Testing : -test <testingFile> <trainedModelFile>\n" +
                "\n" +
                "File Format: \n" +
                "A text file with first line consisting of \"numberOfInstances numOfFeatures\"\n" +
                "Subsequent lines in the following format:\n" +
                "<instID> <featID> <featVal> <featID> <featVal> ... <featID> <featVal> | <class> <class> .. \n" +
                "All values MUST be numeric and featureIDs and ClassIDs must be in sorted order\n" +
                "-------------------------------------------------------");
    }

    public static void main(String args []) {

        if(args.length == 0) {
            printUsage();
            return;
        }
        if(args[0].equalsIgnoreCase("-train")){
            try{
                String trainingFileName = args[1];
                String modelFileName = trainingFileName+".fwcModel";
                if(args.length > 2 && args[2].equalsIgnoreCase("-m")){
                    modelFileName = args[3];
                }
                Features features = Features.getFeaturesFromFile(trainingFileName);
                System.out.println(" -- Data Read --\n" +
                        "Number of Instances:" + features.instanceSize + "\n" +
                        "Number of Features:" + features.featureSize + "\n" +
                        "Number of Classes:" + features.numClasses + "\n");
                FwcClassifier classifier = new FwcClassifier();
                double alpha = classifier.getBestAlpha(features.numClasses, features.featureSize,
                        features.instanceFeatures, features.instanceFeatureValues, features.classValues, features.instanceIds);
                FWCModel model = classifier.trainFWC(features.numClasses, features.featureSize,
                        features.instanceFeatures, features.instanceFeatureValues, features.classValues, features.instanceIds, alpha);
                System.out.println(" -- Model trained, Saving to File -- ");
                Utilities.writeObjectToFile(model,modelFileName);
            }catch(ArrayIndexOutOfBoundsException ae){
                System.out.println(" -- Incorrect parameters -- ");
                printUsage();
            }catch(IOException ioe){
                System.out.println("IO Error!");
                ioe.printStackTrace();
            }catch (Exception e){
                System.out.println(" -- Exception Encountered -- ");
                e.printStackTrace();
            }

        }else if(args[0].equalsIgnoreCase("-test")){
            try{
                String testingFileName = args[1];
                String modelFileName = args[2];
                Features features = Features.getFeaturesFromFile(testingFileName);
                System.out.println(" -- Data Read --\n" +
                        "Number of Instances:" + features.instanceSize + "\n" +
                        "Number of Features:" + features.featureSize + "\n" +
                        "Number of Classes:" + features.numClasses + "\n");
                FwcClassifier classifier = new FwcClassifier();
                FWCModel model = (FWCModel) Utilities.readSavedObjectFile(modelFileName);
                classifier.predictFWC(model,features.instanceFeatures,features.instanceFeatureValues,
                        features.classValues,features.instanceIds,features.numClasses);
                System.out.println("Classification Complete -- \n" +
                        "Accuracy : " + classifier.accuracy + "\n" +
                        "Micro-F1 : " + classifier.f1Micro + "\n" +
                        "Macro-F1 : " + classifier.f1Macro + "\n");

            }catch(ArrayIndexOutOfBoundsException ae){
                System.out.println(" -- Incorrect parameters -- ");
                printUsage();
            }catch(IOException ioe){
                System.out.println("IO Error!");
                ioe.printStackTrace();
            }catch (Exception e){
                System.out.println(" -- Exception Encountered -- ");
                e.printStackTrace();
            }
        }else{
            printUsage();
            return;
        }
    }
}