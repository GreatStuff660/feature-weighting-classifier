import core.*;
import core.methods.ScalingMethod;
import core.utilities.IntegerWrapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class TestFWC_Cluto_LibSVM {

    public static void printUsage(){
        System.out.println("This program applies FWC on a dataset in Cluto or LibSVM format");
        System.out.println("\nUsage:\n" +
                "java -jar FWC.jar clutoMatFilePathOrLibSVMFilePath");
    }

    public static void main(String args []) {

        if(args.length == 0) {
            printUsage();
            return;
        }

        try {
            HashMap<Integer, IntegerWrapper> featureFrequencies = new HashMap<Integer, IntegerWrapper>();
            Object[] trainingDataset = Utilities.readClutoOrLibSVMDataset(args[0], null, null, featureFrequencies, 0, false, false);
            final int numFeatures = (Integer)trainingDataset[0];
            final int numClasses = (Integer)trainingDataset[1];
            final int[][] instanceFeatures = (int[][])trainingDataset[2];
            final double[][] instanceFeatureValues = (double[][])trainingDataset[3];
            final int[][] instanceClassLabels = (int[][])trainingDataset[4];
            final int[] instanceIDs = (int[])trainingDataset[7];
            final boolean[] instanceNegativeAllowed = (boolean[])trainingDataset[9];
            final int noOfFolds = 10;

            System.out.println("Read " + args[0] + ", #instances = " + instanceFeatures.length + ", #features = " + numFeatures + ", #classes = " + numClasses);
            Utilities.scaleDocuments(instanceFeatures, instanceFeatureValues, null, null, null, null,
                    ScalingMethod.TFIDF, numFeatures, instanceFeatures.length, null, null);
            final ExecutorService executorServiceForParameterSelection = Executors.newFixedThreadPool(10);
            final ExecutorService executorServiceForCrossValidation = Executors.newFixedThreadPool(10);
            final int[] folds = Utilities.getStartifiedFoldsForAllInstances(instanceClassLabels, numClasses, noOfFolds);

            final ArrayList<double[][]> allTestScores = new ArrayList<double[][]>();
            final ArrayList<int[][]> allTestInstanceClassLabels = new ArrayList<int[][]>();
            FutureTask<Double>[] tasks = new FutureTask[noOfFolds];
            for (int index = 0; index < noOfFolds; index ++) {
                final int i = index;
                tasks[index] = new FutureTask<Double>(new Callable<Double>() {
                         public Double call() throws Exception {
                             // Get training and test sets
                             Object[] sets = Utilities.getTrainingAndTestSets(i, noOfFolds, folds,
                                     instanceFeatures, instanceFeatureValues, instanceClassLabels, instanceIDs,
                                     instanceNegativeAllowed);
                             int[][] trainingInstanceFeatures = (int[][])sets[0];
                             double[][] trainingInstanceFeatureValues = (double[][])sets[1];
                             int[][] trainingInstanceClassLabels = (int[][])sets[2];
                             int[] trainingInstanceIDs = (int[])sets[3];
                             boolean[] trainingInstanceNegativeAllowed = (boolean[])sets[9];
                             int[][] testInstanceFeatures = (int[][])sets[4];
                             double[][] testInstanceFeatureValues = (double[][])sets[5];
                             int[][] testInstanceClassLabels = (int[][])sets[6];

                             Trainer trainer = new Trainer(numClasses, numFeatures, trainingInstanceFeatures,
                                     trainingInstanceFeatureValues, trainingInstanceClassLabels,
                                     WeightingScheme.INFORMATION_GAIN, WeightAdjustmentScheme.CLASS_SUPPORT, true, true);
                             double alpha = Utilities.autoSelectAlpha(numClasses, numFeatures, trainingInstanceFeatures,
                                     trainingInstanceFeatureValues, trainingInstanceClassLabels, trainingInstanceIDs,
                                     trainingInstanceNegativeAllowed, null, null, null, null, null,
                                     WeightingScheme.INFORMATION_GAIN, WeightAdjustmentScheme.CLASS_SUPPORT, true,
                                     noOfFolds, EvaluationMetric.ACCURACY, null, executorServiceForParameterSelection,
                                     null, "Fold = " + i, false);
                             FWCModel model = trainer.train(alpha);
                             // Now classify
                             Classifier classifier = new Classifier(model);
                             double[][] testScoresForThisFold = classifier.predictScores(testInstanceFeatures, testInstanceFeatureValues);

                             synchronized(allTestScores) {
                                 synchronized(allTestInstanceClassLabels) {
                                     allTestScores.add(testScoresForThisFold);
                                     allTestInstanceClassLabels.add(testInstanceClassLabels);
                                 }
                             }
                             return 0.0;
                         }} );
                  executorServiceForCrossValidation.execute(tasks[index]);
            }

            for (int i = 0; i < noOfFolds; i ++) {
                tasks[i].get();
            }

            int count = 0;
            for (int[][] l : allTestInstanceClassLabels) {
                count += l.length;
            }

            int[][] concolidatedTestInstanceClassLabels = new int[count][];
            double[][] concolidatedTestInstanceClassScores = new double[count][];
            int index = 0;
            for (int i = 0; i < allTestInstanceClassLabels.size(); i ++) {
                int[][] l = allTestInstanceClassLabels.get(i);
                double[][] sc = allTestScores.get(i);
                for (int j = 0; j < l.length; j ++) {
                    concolidatedTestInstanceClassLabels[index] = l[j];
                    concolidatedTestInstanceClassScores[index] = sc[j];
                    index++;
                }
            }

            double crossValidatedAccuracy = Utilities.evaluate(concolidatedTestInstanceClassScores,
                    concolidatedTestInstanceClassLabels, numClasses, EvaluationMetric.ACCURACY);
            double f1Macro = Utilities.evaluate(concolidatedTestInstanceClassScores,
                    concolidatedTestInstanceClassLabels, numClasses, EvaluationMetric.F1MACRO);

            System.out.println("Accuracy = " + crossValidatedAccuracy);
            System.out.println("Macro-F1 = " + f1Macro);

            executorServiceForParameterSelection.shutdown();
            executorServiceForCrossValidation.shutdown();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
