package core;

import core.configuration.GlobalSettings;
import core.methods.ScalingMethod;
import core.utilities.IntegerWrapper;
import core.utilities.ScoreLabelHolder;

import java.io.*;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.FutureTask;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class Utilities {

    private static double[] reducedList = new double[]{0.00001, 0.0001, 0.001, 0.01, 0.05, 0.10, 0.40, 0.80/*, 1*/};
//    private static double[] reducedList = new double[]{0.01};

    private static double[] fullList = new double[]{0.00001, 0.0001, 0.001, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09,
            0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1};


    public static void writeObjectToFile(Object object, String fName) {
        FileOutputStream fos;
        ObjectOutputStream out;
        BufferedOutputStream bout;
        try {
            fos = new FileOutputStream(fName);
            out = new ObjectOutputStream(new BufferedOutputStream(fos));
            out.writeObject(object);
            out.close();
            System.out.println("\t Object written to File : " + fName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Object readSavedObjectFile(String fName) throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fName)));
        return in.readObject();
    }

    private static int partition(double[] a, int p, int r) {
        double x = a[r];
        int i = p - 1;
        for (int j = p; j < r; j++) {
            if (a[j] <= x) {
                i++;
                double temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
        double temp = a[i + 1];
        a[i + 1] = a[r];
        a[r] = temp;
        return i + 1;
    }

    public static int[] getFoldsForAllInstances(int numberOfInstances, int numberOfFolds) {
        Random generator2 = new Random(19580427);
        int[] folds = new int[numberOfInstances];
        for (int i = 0; i < numberOfInstances; i++) {
            folds[i] = (int) (generator2.nextDouble() * numberOfFolds);
        }
        return folds;
    }

    public static int[] getStartifiedFoldsForAllInstances(int[][] instanceClassLabels, int numClasses,
                                                          int numberOfFolds) {
        Random generator2 = new Random(19580427);
        int[] perClassInstanceCount = new int[numClasses];
        for (int[] labels : instanceClassLabels) {
            // For now, we only use the first class...
            perClassInstanceCount[labels[0] - 1]++;
        }
        int[] curFoldForClass = new int[numClasses];
        // Randomly select the first fold for each class...
        for (int i = 0; i < numClasses; i++) {
            curFoldForClass[i] = (int) (generator2.nextDouble() * numberOfFolds);
        }

        // Now decide fold for each instance
        int[] folds = new int[instanceClassLabels.length];
        for (int i = 0; i < instanceClassLabels.length; i++) {
            int instanceClassIndex = instanceClassLabels[i][0] - 1;
            folds[i] = curFoldForClass[instanceClassIndex];
            // Round robin...
            curFoldForClass[instanceClassIndex]++;
            if (curFoldForClass[instanceClassIndex] >= numberOfFolds) {
                curFoldForClass[instanceClassIndex] = 0;
            }
        }
        return folds;
    }



    public static Object[] getTrainingAndTestSets(int currentFold, int numFolds, int[] folds, int[][] instanceFeatures,
                                                  double[][] instanceFeatureValues, int[][] instanceClassLabels,
                                                  int[] instanceIDs, boolean[] instanceNegativeAllowed) {

        int numberOfInstancesInCurrentFold = 0;
        for (int i = 0; i < folds.length; i++) {
            if (folds[i] == currentFold) {
                // Test instance
                numberOfInstancesInCurrentFold++;
            }
        }

        int numberofTrainingInstances = folds.length - numberOfInstancesInCurrentFold;
        int numberofTestInstances = numberOfInstancesInCurrentFold;

        int[][] trainingInstanceFeatures = new int[numberofTrainingInstances][];
        double[][] trainingInstanceFeatureValues = new double[numberofTrainingInstances][];
        int[][] trainingInstanceClassLabels = new int[numberofTrainingInstances][];
        int[] trainingInstanceIDs = new int[numberofTrainingInstances];
        boolean[] trainingInstanceNegativeAllowed = new boolean[numberofTrainingInstances];
        int[][] testInstanceFeatures = new int[numberofTestInstances][];
        double[][] testInstanceFeatureValues = new double[numberofTestInstances][];
        int[][] testInstanceClassLabels = new int[numberofTestInstances][];
        int[] testInstanceIDs = new int[numberofTestInstances];
        boolean[] testInstanceNegativeAllowed = new boolean[numberofTestInstances];
        int[] originalTestInstanceIndices = new int[numberofTestInstances];

        int currentTestIndex = 0, currentTrainingIndex = 0;
        for (int i = 0; i < folds.length; i++) {
            if (folds[i] == currentFold) {
                // Test instance
                testInstanceFeatures[currentTestIndex] = instanceFeatures[i];
                testInstanceFeatureValues[currentTestIndex] = instanceFeatureValues[i];
                testInstanceClassLabels[currentTestIndex] = instanceClassLabels[i];
                testInstanceIDs[currentTestIndex] = instanceIDs[i];
                testInstanceNegativeAllowed[currentTestIndex] = instanceNegativeAllowed[i];
                originalTestInstanceIndices[currentTestIndex] = i;
                currentTestIndex++;
            } else {
                // Training instance
                trainingInstanceFeatures[currentTrainingIndex] = instanceFeatures[i];
                trainingInstanceFeatureValues[currentTrainingIndex] = instanceFeatureValues[i];
                trainingInstanceClassLabels[currentTrainingIndex] = instanceClassLabels[i];
                trainingInstanceIDs[currentTrainingIndex] = instanceIDs[i];
                trainingInstanceNegativeAllowed[currentTrainingIndex] = instanceNegativeAllowed[i];
                currentTrainingIndex++;
            }
        }

        Object[] out = new Object[11];
        out[0] = trainingInstanceFeatures;
        out[1] = trainingInstanceFeatureValues;
        out[2] = trainingInstanceClassLabels;
        out[3] = trainingInstanceIDs;
        out[4] = testInstanceFeatures;
        out[5] = testInstanceFeatureValues;
        out[6] = testInstanceClassLabels;
        out[7] = testInstanceIDs;
        out[8] = originalTestInstanceIndices;
        out[9] = trainingInstanceNegativeAllowed;
        out[10] = testInstanceNegativeAllowed;
        return out;
    }

    public static int[] convertToTFIDF(int[][] instanceFeatures, double[][] instanceFeatureValues, int featureCount,
                                       int instanceCount, int[] featureSupports, int[] featureIndicesOverride,
                                       boolean useLogTF) {

        // First update feature supports
        if (featureSupports == null) {
            featureSupports = new int[featureCount + 1];
            for (int i = 0; i < instanceFeatures.length; i++) {
                // Process all features
                for (int f = 0; f < instanceFeatures[i].length; f++) {
                    // Update global feature support...
                    if (instanceFeatureValues[i][f] != 0) {
                        featureSupports[instanceFeatures[i][f]]++;
                    }
                }
            }
        }

        // Now compute TFIDF
        for (int i = 0; i < instanceFeatures.length; i++) {
            // Process all features
            for (int f = 0; f < instanceFeatures[i].length; f++) {
                // Update global feature support...
                int featureID = instanceFeatures[i][f];
                if (featureIndicesOverride != null) {
                    if (featureID < featureIndicesOverride.length) {
                        featureID = featureIndicesOverride[featureID];
                    } else {
                        instanceFeatureValues[i][f] = Double.POSITIVE_INFINITY;
                        continue;
                    }
                }
                if (instanceFeatureValues[i][f] != 0 && featureID < featureCount) {
                    instanceFeatureValues[i][f] = (useLogTF ? Math.log(1 + instanceFeatureValues[i][f]) : instanceFeatureValues[i][f]) * Math.log(instanceCount / (double) featureSupports[featureID]);
                }
            }
        }

        return featureSupports;
    }

    /**
     * Document length normalization, using the L2-norm (http://www.stanford.edu/class/cs276/handouts/lecture6-tfidf.pdf)
     *
     * @param instanceFeatureValues
     */
    public static void normalizeToDocumentLength(double[][] instanceFeatureValues) {

        for (int i = 0; i < instanceFeatureValues.length; i++) {
            // First compute the sum
            double sum = 0;
            // Process all features
            for (int f = 0; f < instanceFeatureValues[i].length; f++) {
                double v = instanceFeatureValues[i][f];
                if (v != Double.POSITIVE_INFINITY) {
                    sum += (v * v);
                }
            }
            sum = Math.sqrt(sum);
            // Now normalize
            for (int f = 0; f < instanceFeatureValues[i].length; f++) {
                instanceFeatureValues[i][f] /= sum;
            }
        }
    }

    public static void normalizeBetweenZeroAndOne(double[][] instanceFeatureValues) {

        for (int i = 0; i < instanceFeatureValues.length; i++) {
            if (instanceFeatureValues[i].length == 1) {
                // Avoid generating an infinity value in this case....
                instanceFeatureValues[i][0] = 0.999999;
                continue;
            }
            // First find min and max
            double min = Double.POSITIVE_INFINITY;
            double max = Double.NEGATIVE_INFINITY;
            // Process all features
            for (double v : instanceFeatureValues[i]) {
                if (v == Double.POSITIVE_INFINITY) continue;
                if (v < min) min = v;
                if (v > max) max = v;
            }

            double maxMinusMin = max - min;

            // Now normalize
            for (int f = 0; f < instanceFeatureValues[i].length; f++) {
                instanceFeatureValues[i][f] = (instanceFeatureValues[i][f] - min) / maxMinusMin;
                if (instanceFeatureValues[i][f] == 0) instanceFeatureValues[i][f] = 0.00001;
                else if (instanceFeatureValues[i][f] == 1) instanceFeatureValues[i][f] = 0.999999;
            }
        }
    }

    public static int[][] getPredictedLabelsUsingMaxScore(int numClasses, double[][] scores) {
        int[][] predictedLabels = new int[scores.length][1];
        boolean allowZeroes = numClasses == 2 ? true : false;
        for (int i = 0; i < scores.length; i++) {
            predictedLabels[i][0] = getIndexWithMaxScore(scores[i], allowZeroes) + 1;
        }
        return predictedLabels;
    }

    public static double evaluate(double[][] scores, int[][] classLabels, int classCount, EvaluationMetric metric) {

        int[][] predictedLabels = getPredictedLabelsUsingMaxScore(classCount, scores);
        return evaluate(predictedLabels, classLabels, classCount, metric);
    }

    public static double evaluate(int[][] predictedLabels, int[][] classLabels, int classCount,
                                  EvaluationMetric metric) {
        if (metric == EvaluationMetric.ACCURACY) {
            // Accuracy assumes that the number of prdictions made for an instance is not greater than the actual number of labels
            double correct = 0;
            int total = 0;
            for (int i = 0; i < classLabels.length; i++) {
                for (int predicted : predictedLabels[i]) {
                    if (Arrays.binarySearch(classLabels[i], predicted) >= 0) {
                        correct++;
                    }
                }
                total += classLabels[i].length;
                /*if (predictedLabels[i][0] == classLabels[i][0]) {
                    correct++;
                }*/
            }
            return correct / total;
        } else if (metric == EvaluationMetric.F1MICRO || metric == EvaluationMetric.F1MACRO ||
                metric == EvaluationMetric.F1_POSITIVE_CLASS) {
            int[] perClassActualTotal = new int[classCount];
            int[] perClassPredictedTotal = new int[classCount];
            int[] perClassCorrectTotal = new int[classCount];
            int totalLabelUsage = 0;
            for (int i = 0; i < classLabels.length; i++) {
                for (int actual : classLabels[i]) {
                    perClassActualTotal[actual - 1]++;
                }

                for (int predicted : predictedLabels[i]) {
                    perClassPredictedTotal[predicted - 1]++;
                    if (Arrays.binarySearch(classLabels[i], predicted) >= 0) {
                        perClassCorrectTotal[predicted - 1]++;
                    }
                }
                totalLabelUsage += classLabels[i].length;
            }
            if (metric == EvaluationMetric.F1MICRO) {
                // Merge the confusion matrices (sort of...)
                int sumPerClassCorrectTotal = 0, sumPerClassPredictedTotal = 0, sumPerClassActualTotal = 0;
                for (int i = 0; i < classCount; i++) {
                    sumPerClassCorrectTotal += perClassCorrectTotal[i];
                    sumPerClassPredictedTotal += perClassPredictedTotal[i];
                    sumPerClassActualTotal += perClassActualTotal[i];
                }
                double precision = sumPerClassCorrectTotal / (double) sumPerClassPredictedTotal;
                double recall = sumPerClassCorrectTotal / (double) sumPerClassActualTotal;

                return ((2 * precision * recall) / (precision + recall));
            } else {
                double[] perClassPrecision = new double[classCount];
                double[] perClassRecall = new double[classCount];
                double[] perClassFScores = new double[classCount];
                for (int i = 0; i < classCount; i++) {
                    perClassPrecision[i] = perClassCorrectTotal[i] / (double) perClassPredictedTotal[i];
                    perClassRecall[i] = perClassCorrectTotal[i] / (double) perClassActualTotal[i];
                    if (!(perClassPrecision[i] == 0 && perClassRecall[i] == 0) && !Double.isNaN(perClassPrecision[i]) && !Double.isNaN(perClassRecall[i])) {
                        perClassFScores[i] = ((2 * perClassPrecision[i] * perClassRecall[i]) / (perClassPrecision[i] + perClassRecall[i]));
                    }
                }
                if (metric == EvaluationMetric.F1_POSITIVE_CLASS) {
                    return perClassFScores[0];
                } else {

                }
                // Compute the number of classes with atleast one true label
                int classesUsed = 0;
                for (int c : perClassActualTotal) {
                    if (c > 0) classesUsed++;
                }
                double total = 0;
                for (int i = 0; i < classCount; i++) {
                    total += perClassFScores[i];
                }
                return total / classesUsed;
            }
        } else if (metric == EvaluationMetric.PRECISION_RANK1) {
            double correct = 0;
            int predictedCount = 0;
            for (int i = 0; i < classLabels.length; i++) {
                if (predictedLabels[i].length > 0) {
                    int classAtRank1 = predictedLabels[i][0];
                    if (Arrays.binarySearch(classLabels[i], classAtRank1) >= 0) {
                        correct++;
                    }
                    predictedCount++;
                }
            }
            return correct / predictedCount;
        }

        return -1;
    }

    public static Object[] getPerClassFScores(int[][] predictedLabels, int[][] classLabels, int classCount) {
        int[] perClassActualTotal = new int[classCount];
        int[] perClassPredictedTotal = new int[classCount];
        int[] perClassCorrectTotal = new int[classCount];
        int totalLabelUsage = 0;
        for (int i = 0; i < classLabels.length; i++) {
            for (int actual : classLabels[i]) {
                perClassActualTotal[actual - 1]++;
            }

            for (int predicted : predictedLabels[i]) {
                perClassPredictedTotal[predicted - 1]++;
                if (Arrays.binarySearch(classLabels[i], predicted) >= 0) {
                    perClassCorrectTotal[predicted - 1]++;
                }
            }
            totalLabelUsage += classLabels[i].length;
        }
        double[] perClassPrecision = new double[classCount];
        double[] perClassRecall = new double[classCount];
        double[] perClassFScores = new double[classCount];
        for (int i = 0; i < classCount; i++) {
            perClassPrecision[i] = perClassCorrectTotal[i] / (double) perClassPredictedTotal[i];
            perClassRecall[i] = perClassCorrectTotal[i] / (double) perClassActualTotal[i];
            if (!(perClassPrecision[i] == 0 && perClassRecall[i] == 0) && !Double.isNaN(perClassPrecision[i]) && !Double.isNaN(perClassRecall[i])) {
                perClassFScores[i] = ((2 * perClassPrecision[i] * perClassRecall[i]) / (perClassPrecision[i] + perClassRecall[i]));
            }
        }
        return new Object[]{perClassFScores, perClassPrecision, perClassRecall, perClassActualTotal,
                perClassPredictedTotal, perClassCorrectTotal};
    }

    public static int getIndexWithMaxScore(double[] array, boolean allowZeroes) {

        int index = 0;
        double maxScore = Double.NEGATIVE_INFINITY;
        if (allowZeroes) {
            for (int i = 0; i < array.length; i++) {
                if (array[i] > maxScore) {
                    maxScore = array[i];
                    index = i;
                }
            }
        } else {
            for (int i = 0; i < array.length; i++) {
                // Can't consider zero values because of SVM issues...
                if (array[i] != 0 && array[i] > maxScore) {
                    maxScore = array[i];
                    index = i;
                }
            }
        }
        return index;
    }

    public static Object[] readClutoOrLibSVMDataset(String clutoMatrixFileOrLibSVMDatasetLocation,
                                                    HashMap<String, Integer> priorClassLabels,
                                                    HashMap<Integer, Integer> featureIDToIndexMapping,
                                                    HashMap<Integer, IntegerWrapper> featureFrequencies,
                                                    int priorInstanceCount,
                                                    boolean ignoreUnknownFeatures,
                                                    boolean allowInstancesAsPositiveOnlyForSVM) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(clutoMatrixFileOrLibSVMDatasetLocation));
        String firstLine = r.readLine();
        r.close();
        if (firstLine == null) return null;
        if (firstLine.indexOf(':') > 0) {
            return readLibSVMDataset(clutoMatrixFileOrLibSVMDatasetLocation, priorClassLabels, featureIDToIndexMapping,
                    true, featureFrequencies, priorInstanceCount, ignoreUnknownFeatures, allowInstancesAsPositiveOnlyForSVM);
        } else {
            return readClutoDataset(clutoMatrixFileOrLibSVMDatasetLocation, priorClassLabels, featureIDToIndexMapping,
                    featureFrequencies, priorInstanceCount, ignoreUnknownFeatures, allowInstancesAsPositiveOnlyForSVM);
        }

    }

    public static Object[] readClutoDataset(String clutoMatrixFileLocation, HashMap<String, Integer> priorClassLabels,
                                            HashMap<Integer, Integer> priorFeatureIDToIndexMapping,
                                            HashMap<Integer, IntegerWrapper> featureFrequencies, int priorInstanceCount,
                                            boolean ignoreUnknownFeatures,
                                            boolean allowInstancesAsPositiveOnlyForSVM) throws IOException {
        BufferedReader matrixFile = new BufferedReader(new FileReader(clutoMatrixFileLocation));
        BufferedReader rowClassFile = new BufferedReader(new FileReader(clutoMatrixFileLocation + ".rClass"));
        BufferedReader negativeAllowedFile = allowInstancesAsPositiveOnlyForSVM && new File(clutoMatrixFileLocation + ".negativeAllowed").exists()
                ? new BufferedReader(new FileReader(clutoMatrixFileLocation + ".negativeAllowed")) : null;
        StringTokenizer token = new StringTokenizer(matrixFile.readLine());
        HashMap<String, Integer> classLabels = priorClassLabels == null ? new HashMap<String, Integer>() : priorClassLabels;
        HashMap<Integer, Integer> featureIndices = priorFeatureIDToIndexMapping == null ? new HashMap<Integer, Integer>() : priorFeatureIDToIndexMapping;
        int numRows, numCols, numEntries;
        if (token.countTokens() == 3) {
            numRows = Integer.parseInt(token.nextToken());
            numCols = Integer.parseInt(token.nextToken());
            numEntries = Integer.parseInt(token.nextToken());
            int[][] instanceFeatures = new int[numRows][];
            double[][] instanceFeatureValues = new double[numRows][];
            int[][] instanceClassLabels = new int[numRows][];
            int instanceID = priorInstanceCount > 0 ? priorInstanceCount : 0;
            int[] instanceIDs = new int[numRows];
            boolean[] negativeAllowed = new boolean[numRows];
            if (negativeAllowedFile == null) Arrays.fill(negativeAllowed, true);
            for (int i = 0; i < numRows; i++) {
                // First read the class label
                StringTokenizer tok = new StringTokenizer(rowClassFile.readLine());
                instanceClassLabels[i] = new int[tok.countTokens()];
                int index = 0;
                while (tok.hasMoreTokens()) {
                    String label = tok.nextToken();
                    Integer classID = classLabels.get(label);
                    if (classID == null) {
                        classID = classLabels.size() + 1;
                        classLabels.put(label, classID);
                    }
                    instanceClassLabels[i][index++] = classID;
                }
                if (negativeAllowedFile != null)
                    negativeAllowed[i] = Boolean.parseBoolean(negativeAllowedFile.readLine());
                String str = matrixFile.readLine();
                StringTokenizer columnsInThisRow = new StringTokenizer(str);
                int totalColumns = columnsInThisRow.countTokens() / 2;
                instanceFeatures[i] = new int[totalColumns];
                instanceFeatureValues[i] = new double[totalColumns];
                TreeSet<FeatureIDSorter> set = new TreeSet<FeatureIDSorter>();
                for (int j = 0; j < totalColumns; j++) {
                    int colID = Integer.parseInt(columnsInThisRow.nextToken());
                    double value = Double.parseDouble(columnsInThisRow.nextToken());
                    Integer featureIndex = featureIndices.get(colID);
                    if (featureIndex == null) {
                        if (ignoreUnknownFeatures) continue;
                        featureIndex = featureIndices.size() + 1;
                        featureIndices.put(colID, featureIndex);
                    }
                    if (featureFrequencies != null) {
                        IntegerWrapper w = featureFrequencies.get(featureIndex);
                        if (w == null) {
                            w = new IntegerWrapper();
                            featureFrequencies.put(featureIndex, w);
                        }
                        w.data++;
                    }
                    set.add(new FeatureIDSorter(featureIndex, value));
                }

                index = 0;
                for (FeatureIDSorter f : set) {
                    instanceFeatures[i][index] = f.featureID;
                    instanceFeatureValues[i][index] = f.value;
                    index++;
                }
                instanceIDs[i] = instanceID++;
            }
            matrixFile.close();
            rowClassFile.close();
            if (negativeAllowedFile != null) negativeAllowedFile.close();
            Object[] out = new Object[10];
            out[0] = featureIndices.size()/*numCols*/;
            out[1] = classLabels.size();
            out[2] = instanceFeatures;
            out[3] = instanceFeatureValues;
            out[4] = instanceClassLabels;
            out[5] = classLabels;
            out[6] = featureIndices;
            out[7] = instanceIDs;
            out[8] = instanceID;
            out[9] = negativeAllowed;
            return out;
        } else {
            System.out.println("Error, invalid CLUTO Matrix");
            return null;
        }

    }

    public static Object[] readLibSVMDataset(String fileLocation, HashMap<String, Integer> priorClassLabels,
                                             HashMap<Integer, Integer> priorFeatureIDToIndexMapping,
                                             boolean ignoreFeatureWithIndexZero,
                                             HashMap<Integer, IntegerWrapper> featureFrequencies,
                                             int priorInstanceCount,
                                             boolean ignoreUnknownFeatures,
                                             boolean allowInstancesAsPositiveOnlyForSVM) throws IOException {

        BufferedReader r = new BufferedReader(new FileReader(fileLocation), 1000000);
        HashMap<String, Integer> classLabels = priorClassLabels == null ? new HashMap<String, Integer>() : priorClassLabels;
        HashMap<Integer, Integer> featureIndices = priorFeatureIDToIndexMapping == null ? new HashMap<Integer, Integer>() : priorFeatureIDToIndexMapping;
        String str = null;
        ArrayList<int[]> instanceFeatureList = new ArrayList<int[]>();
        ArrayList<double[]> instanceFeatureValueList = new ArrayList<double[]>();
        ArrayList<int[]> instanceClassLabelList = new ArrayList<int[]>();
        int maxFeatureIndex = 0;
        while ((str = r.readLine()) != null) {
            StringTokenizer tokenizer = new StringTokenizer(str, " ");
            // Read the class...
            String label = tokenizer.nextToken();
            Integer classID = classLabels.get(label);
            if (classID == null) {
                classID = classLabels.size() + 1;
                classLabels.put(label, classID);
            }
            instanceClassLabelList.add(new int[]{classID});
            int[] features = null;
            double[] featureValues = null;
            int cur = 0;
            while (tokenizer.hasMoreTokens()) {
                cur++;
                StringTokenizer tok2 = new StringTokenizer(tokenizer.nextToken(), ":");
                int f = Integer.parseInt(tok2.nextToken());
                double v = Double.parseDouble(tok2.nextToken());
                if (f == 0 && ignoreFeatureWithIndexZero) continue;
                if (features == null) {
                    features = new int[tokenizer.countTokens() + 1];
                    featureValues = new double[features.length];
                    cur = 0;
                }
                Integer featureIndex = featureIndices.get(f);
                if (featureIndex == null) {
                    if (ignoreUnknownFeatures) {
                        cur--;
                        continue;
                    }
                    featureIndex = featureIndices.size() + 1;
                    featureIndices.put(f, featureIndex);
                }
                features[cur] = featureIndex;
                featureValues[cur] = v;
                if (f > maxFeatureIndex) maxFeatureIndex = f;
                if (featureFrequencies != null) {
                    IntegerWrapper w = featureFrequencies.get(featureIndex);
                    if (w == null) {
                        w = new IntegerWrapper();
                        featureFrequencies.put(featureIndex, w);
                    }
                    w.data++;
                }
            }
            if (cur < (features.length - 1)) {
                // May happen if ignoreUnknownFeatures = true and this instance contains unknown features
                int[] featuresNew = new int[cur + 1];
                double[] featureValuesNew = new double[cur + 1];
                System.arraycopy(features, 0, featuresNew, 0, cur + 1);
                System.arraycopy(featureValues, 0, featureValuesNew, 0, cur + 1);
                features = featuresNew;
                featureValues = featureValuesNew;
            }
            instanceFeatureList.add(features);
            instanceFeatureValueList.add(featureValues);
        }
        r.close();
        int numRows = instanceFeatureList.size();
        int[][] instanceFeatures = new int[numRows][];
        double[][] instanceFeatureValues = new double[numRows][];
        int[][] instanceClassLabels = new int[numRows][];
        int instanceID = priorInstanceCount > 0 ? priorInstanceCount : 0;
        int[] instanceIDs = new int[numRows];
        for (int i = 0; i < numRows; i++) {
            instanceFeatures[i] = instanceFeatureList.get(i);
            instanceFeatureValues[i] = instanceFeatureValueList.get(i);
            instanceClassLabels[i] = instanceClassLabelList.get(i);
            instanceIDs[i] = instanceID++;
        }
        BufferedReader negativeAllowedFile = allowInstancesAsPositiveOnlyForSVM && new File(fileLocation + ".negativeAllowed").exists()
                ? new BufferedReader(new FileReader(fileLocation + ".negativeAllowed")) : null;
        boolean[] negativeAllowed = new boolean[numRows];
        if (negativeAllowedFile == null) Arrays.fill(negativeAllowed, true);
        else {
            for (int i = 0; i < numRows; i++) {
                if (negativeAllowedFile != null)
                    negativeAllowed[i] = Boolean.parseBoolean(negativeAllowedFile.readLine());
            }
        }
        if (negativeAllowedFile != null) negativeAllowedFile.close();
        Object[] out = new Object[10];
        out[0] = featureIndices.size();
        out[1] = classLabels.size();
        out[2] = instanceFeatures;
        out[3] = instanceFeatureValues;
        out[4] = instanceClassLabels;
        out[5] = classLabels;
        out[6] = featureIndices;
        out[7] = instanceIDs;
        out[8] = instanceID;
        out[9] = negativeAllowed;
        return out;
    }

    public static double autoSelectAlpha(int classCount, int featureCount, int[][] trainingInstanceFeatures,
                                         double[][] trainingInstanceFeatureValues, int[][] trainingInstanceClassLabels,
                                         int[] trainingInstanceIDs, boolean[] trainingInstanceNegativeAllowed,
                                         int[][] validationInstanceFeatures, double[][] validationInstanceFeatureValues,
                                         int[][] validationInstanceClassLabels, int[] validationInstanceIDs,
                                         boolean[] validationInstanceNegativeAllowed,
                                         WeightingScheme weightingScheme, WeightAdjustmentScheme weightAdjustmentScheme,
                                         boolean penalizeFeaturesForClassDuplication,
                                         int noOfFolds, EvaluationMetric evaluationMetric, StringBuffer buff,
                                         ExecutorService executorServiceForParameterSelection,
                                         ScoreLabelHolder scoreLabelHolderForComputingProbabilities, String info,
                                         boolean useReducedAlphaList) throws Exception {
        return autoSelectAlphaFullOrReducedPowerList(classCount, featureCount, trainingInstanceFeatures,
                trainingInstanceFeatureValues, trainingInstanceClassLabels, trainingInstanceIDs,
                trainingInstanceNegativeAllowed, validationInstanceFeatures, validationInstanceFeatureValues,
                validationInstanceClassLabels, validationInstanceIDs, validationInstanceNegativeAllowed, weightingScheme,
                weightAdjustmentScheme, penalizeFeaturesForClassDuplication, noOfFolds, evaluationMetric, buff,
                useReducedAlphaList, executorServiceForParameterSelection, scoreLabelHolderForComputingProbabilities, info);
    }

    public static double autoSelectAlphaFullOrReducedPowerList(final int classCount, final int featureCount,
                                                               final int[][] instanceFeatures,
                                                               final double[][] instanceFeatureValues,
                                                               final int[][] instanceClassLabels,
                                                               final int[] instanceIDs,
                                                               final boolean[] instanceNegativeAllowed,
                                                               final int[][] validationInstanceFeatures,
                                                               final double[][] validationInstanceFeatureValues,
                                                               final int[][] validationInstanceClassLabels,
                                                               final int[] validationInstanceIDs,
                                                               final boolean[] validationInstanceNegativeAllowed,
                                                               final WeightingScheme weightingScheme,
                                                               final WeightAdjustmentScheme weightAdjustmentScheme,
                                                               final boolean penalizeFeaturesForClassDuplication,
                                                               int noOfFolds,
                                                               final EvaluationMetric evaluationMetric,
                                                               StringBuffer buff,
                                                               boolean useReducedPowerList,
                                                               final ExecutorService executorService,
                                                               ScoreLabelHolder scoreLabelHolderForComputingProbabilities,
                                                               String info) throws Exception {

        long t1 = System.currentTimeMillis();
        double best = -1;
        double bestScore = 0;

        final double[] powerList = useReducedPowerList ? reducedList : fullList;

        // Schedule all tasks
//        final int[] folds = validationInstanceFeatures != null ? null : Utilities.getFoldsForAllInstances(instanceFeatures.length, noOfFolds);
        final int[] folds = validationInstanceFeatures != null ? null : Utilities.getStartifiedFoldsForAllInstances(
                instanceClassLabels, classCount, noOfFolds);
        noOfFolds = validationInstanceFeatures != null ? 1 : noOfFolds;

        int[][] labelsForComputingProbabilities = null;
        int[] instanceIDsForRefinement = null;
//        int[][] instanceFeaturesForRefinement = null;
//        double[][] instanceFeatureValuesForRefinement = null;
        final double[][][] allScoresForComputingProbabilities;
        int index = 0;
        if (scoreLabelHolderForComputingProbabilities != null) {
            if (validationInstanceFeatures == null) {
                allScoresForComputingProbabilities = new double[powerList.length][instanceFeatures.length][];
//                instanceFeaturesForRefinement = new int[instanceFeatures.length][];
//                instanceFeatureValuesForRefinement = new double[instanceFeatures.length][];
                instanceIDsForRefinement = new int[instanceFeatures.length];
                labelsForComputingProbabilities = new int[instanceFeatures.length][];
                for (int i = 0; i < noOfFolds; i++) {
                    // Get training and test sets
                    Object[] sets = Utilities.getTrainingAndTestSets(i, noOfFolds, folds, instanceFeatures,
                            instanceFeatureValues, instanceClassLabels, instanceIDs, instanceNegativeAllowed);
//                    int[][] testInstanceFeatures = (int[][])sets[4];
//                    double[][] testInstanceFeatureValues = (double[][])sets[5];
                    int[][] testInstanceClassLabels = (int[][]) sets[6];
                    int[] testInstanceIDs = (int[]) sets[7];
//                    System.arraycopy(testInstanceFeatures, 0, instanceFeaturesForRefinement, index, testInstanceClassLabels.length);
//                    System.arraycopy(testInstanceFeatureValues, 0, instanceFeatureValuesForRefinement, index, testInstanceClassLabels.length);
                    System.arraycopy(testInstanceClassLabels, 0, labelsForComputingProbabilities, index, testInstanceClassLabels.length);
                    System.arraycopy(testInstanceIDs, 0, instanceIDsForRefinement, index, testInstanceIDs.length);
                    index += testInstanceClassLabels.length;
                }
                index = 0;
            } else {
                allScoresForComputingProbabilities = new double[powerList.length][validationInstanceFeatures.length][];
//                instanceFeaturesForRefinement = validationInstanceFeatures;
//                instanceFeatureValuesForRefinement = validationInstanceFeatureValues;
                labelsForComputingProbabilities = validationInstanceClassLabels;
                instanceIDsForRefinement = validationInstanceIDs;
            }
        } else allScoresForComputingProbabilities = null;

        // Switched to a per-fold thread. Broke validation instance funationality. TODO: Fix it!!!

        int foldsWithNoTestInstances = 0;
//        FutureTask<Double>[] tasks = new FutureTask[powerList.length];
        long t2 = System.currentTimeMillis();
        final double[][] results = new double[noOfFolds][powerList.length];
        final Trainer[] trainersForAllFolds = new Trainer[noOfFolds];
        final Object[][] setsForEachFold = new Object[noOfFolds][];
        int indexTrainer = 0;
        FutureTask<Double>[] tasksForTrainerCreation = new FutureTask[noOfFolds];
        for (int i = 0; i < noOfFolds; i++) {
            final int[][] trainingInstanceFeatures;
            final double[][] trainingInstanceFeatureValues;
            final int[][] trainingInstanceClassLabels;
            final int[][] testInstanceFeatures;
            final double[][] testInstanceFeatureValues;
            final int[][] testInstanceClassLabels;
            final int[] originalTestInstanceIndices;
            if (validationInstanceFeatures == null) {
                final Object[] sets = core.Utilities.getTrainingAndTestSets(i, noOfFolds, folds,
                        instanceFeatures, instanceFeatureValues, instanceClassLabels, instanceIDs, instanceNegativeAllowed);
                trainingInstanceFeatures = (int[][]) sets[0];
                trainingInstanceFeatureValues = (double[][]) sets[1];
                trainingInstanceClassLabels = (int[][]) sets[2];
                testInstanceFeatures = (int[][]) sets[4];
                testInstanceFeatureValues = (double[][]) sets[5];
                testInstanceClassLabels = (int[][]) sets[6];
                originalTestInstanceIndices = (int[]) sets[8];
            } else {
                trainingInstanceFeatures = instanceFeatures;
                trainingInstanceFeatureValues = instanceFeatureValues;
                trainingInstanceClassLabels = instanceClassLabels;
                testInstanceFeatures = validationInstanceFeatures;
                testInstanceFeatureValues = validationInstanceFeatureValues;
                testInstanceClassLabels = validationInstanceClassLabels;
                originalTestInstanceIndices = validationInstanceIDs;
            }
            if (trainingInstanceFeatures.length == 0 || testInstanceFeatures.length == 0) {
                foldsWithNoTestInstances++;
                continue;
            }
            final int indexTrainerCopy = indexTrainer;
            tasksForTrainerCreation[indexTrainer] = new FutureTask<Double>(new Callable<Double>() {
                public Double call() {
                    final Trainer trainer = new Trainer(classCount, featureCount, trainingInstanceFeatures,
                            trainingInstanceFeatureValues, trainingInstanceClassLabels, weightingScheme,
                            weightAdjustmentScheme, penalizeFeaturesForClassDuplication, true);
                    trainersForAllFolds[indexTrainerCopy] = trainer;
                    setsForEachFold[indexTrainerCopy] = new Object[]{testInstanceFeatures, testInstanceFeatureValues,
                            testInstanceClassLabels, originalTestInstanceIndices};
                    return new Double(0);
                }
            });
            executorService.execute(tasksForTrainerCreation[indexTrainer]);
            indexTrainer++;
        }

        for (int j = 0; j < indexTrainer; j++) {
            tasksForTrainerCreation[j].get();
        }

        if (GlobalSettings.debugEnabled && GlobalSettings.verbose) {
            System.out.println("Time trainer object creation: " + ((System.currentTimeMillis() - t2) / 1000.0));
        }

        FutureTask<Double>[] tasksForAlphaComputation = new FutureTask[powerList.length];
        for (int i = 0; i < indexTrainer; i++) {
            final int fold = i;
            final Trainer trainer = trainersForAllFolds[i];
            Object[] sets = setsForEachFold[i];
            final int[][] testInstanceFeatures = (int[][]) sets[0];
            final double[][] testInstanceFeatureValues = (double[][]) sets[1];
            final int[][] testInstanceClassLabels = (int[][]) sets[2];
            final int[] originalTestInstanceIndices = (int[]) sets[3];
            long t3 = System.currentTimeMillis();
            for (int alphaIndex = 0; alphaIndex < powerList.length; alphaIndex++) {
                final int cIndex = alphaIndex;
                final double alpha = powerList[cIndex];
                tasksForAlphaComputation[alphaIndex] = new FutureTask<Double>(new Callable<Double>() {
                    public Double call() throws Exception {
                        long t1 = System.currentTimeMillis();
                        FWCModel model = trainer.train(alpha);
                        long t2 = System.currentTimeMillis();
                        Classifier classifier = new Classifier(model);
                        double[][] scores = classifier.predictScores(testInstanceFeatures, testInstanceFeatureValues);
                        long t3 = System.currentTimeMillis();
                        if (allScoresForComputingProbabilities != null) {
//                                System.arraycopy(scores, 0, allScoresForComputingProbabilities[cIndex], sIndex, scores.length);
//                                sIndex += scores.length;
                            for (int ind = 0; ind < originalTestInstanceIndices.length; ind++) {
                                allScoresForComputingProbabilities[cIndex][originalTestInstanceIndices[ind]] = scores[ind];
                            }
                        }
                        long t4 = System.currentTimeMillis();
                        double score = Utilities.evaluate(scores, testInstanceClassLabels, classCount, evaluationMetric);
//                System.out.println("Alpha = " + alphaOrC + ", fold = " + (i + 1) + ", score = " + score);
                        results[fold][cIndex] = score;
                        if (GlobalSettings.debugEnabled && GlobalSettings.verbose) {
                            long t5 = System.currentTimeMillis();
                            System.out.println("Alpha=" + alpha + ", time1: " + ((t2 - t1) / 1000.0) + ", time2: " + ((t3 - t2) / 1000.0) + ", time3: " + ((t4 - t3) / 1000.0) + ", time4: " + ((t5 - t4) / 1000.0) + ", total: " + ((t5 - t1) / 1000.0));
                        }
                        return new Double(0);
                    }
                });
                executorService.execute(tasksForAlphaComputation[alphaIndex]);

            }

            for (int j = 0; j < tasksForAlphaComputation.length; j++) {
                tasksForAlphaComputation[j].get();
            }
            if (GlobalSettings.debugEnabled && GlobalSettings.verbose) {
                System.out.println("Fold: " + (i + 1) + ", time = " + ((System.currentTimeMillis() - t3) / 1000.0));
            }
        }


        // Compute quality for each alphaOrC and find best alphaOrC
        int bestIndex = 0;
        for (int i = 0; i < powerList.length; i++) {
            double sumScores = 0;
            for (int j = 0; j < (noOfFolds - foldsWithNoTestInstances); j++) {
                sumScores += results[j][i];
            }
            double score = sumScores / (noOfFolds - foldsWithNoTestInstances);
            if (score > bestScore) {
                best = powerList[i];
                bestScore = score;
                bestIndex = i;
            }
        }

        /*final Trainer[] trainersForAllFolds = new Trainer[noOfFolds];
        for (final double power : powerList) {
            final int cIndex = index;
            tasks[index] = new FutureTask<Double>(new Callable<Double>() {
                public Double call() throws Exception {
                    Trainer trainer = null;
                    double s = 0;
                    if (validationInstanceFeatures == null) {
                        // Cross validation

                        double sumScores = 0;
                        int foldsWithNoTestInstances = 0;
                        int sIndex = 0;
                        for (int i = 0; i < noOfFolds; i ++) {
                            // Get training and test sets
                            Object[] sets = FeatureWeightingClassifier.Utilities.getTrainingAndTestSets(i, noOfFolds, folds,
                                    instanceFeatures, instanceFeatureValues, instanceClassLabels, instanceIDs);
                            int[][] trainingInstanceFeatures = (int[][])sets[0];
                            double[][] trainingInstanceFeatureValues = (double[][])sets[1];
                            int[][] trainingInstanceClassLabels = (int[][])sets[2];
                            int[] trainingInstanceIDs = (int[])sets[3];
                            int[][] testInstanceFeatures = (int[][])sets[4];
                            double[][] testInstanceFeatureValues = (double[][])sets[5];
                            int[][] testInstanceClassLabels = (int[][])sets[6];
                            int[] testInstanceIDs = (int[])sets[7];
                            int[] originalTestInstanceIndices = (int[])sets[8];

                            if (trainingInstanceFeatures.length == 0 || testInstanceFeatures.length == 0) {
                                foldsWithNoTestInstances++;
                                continue;
                            }

                            if (trainersForAllFolds[i] == null) {
                                trainer = new Trainer(classCount, featureCount,
                                        trainingInstanceFeatures, trainingInstanceFeatureValues, trainingInstanceClassLabels, minSupport,
                                        minLocalCoverage, weightingScheme, weightAdjustmentScheme, featureSelectionScheme,
                                        power, maxFeaturesToSelect, ignoreMinSupportForCoverage, penalizeFeaturesForClassDuplication, true);
                                trainersForAllFolds[i] = trainer;
                                System.out.println("New trainer...");
                            } else {
                                trainer = trainersForAllFolds[i];
                                trainer.setAlpha(power);
                            }

                            FWCModel model = trainer.train();
                            Classifier classifier = new Classifier(model);
                            double[][] scores = classifier.predictScores(testInstanceFeatures, testInstanceFeatureValues);
                            if (allScoresForComputingProbabilities != null) {
//                                System.arraycopy(scores, 0, allScoresForComputingProbabilities[cIndex], sIndex, scores.length);
//                                sIndex += scores.length;
                                for (int ind = 0; ind < originalTestInstanceIndices.length; ind++) {
                                    allScoresForComputingProbabilities[cIndex][originalTestInstanceIndices[ind]] = scores[ind];
                                }
                            }
                            double score = Utilities.evaluate(scores, testInstanceClassLabels, classCount,
                                    evaluationMetric, ClassificationMethod.FWC);
//                System.out.println("Alpha = " + power + ", fold = " + (i + 1) + ", score = " + score);
                            sumScores += score;
                        }

                        return sumScores / (noOfFolds - foldsWithNoTestInstances);
                    } else {
                        if (trainer == null) {
                            trainer = new Trainer(classCount, featureCount,
                                    instanceFeatures, instanceFeatureValues, instanceClassLabels, minSupport,
                                    minLocalCoverage, weightingScheme, weightAdjustmentScheme, featureSelectionScheme,
                                    power, maxFeaturesToSelect, ignoreMinSupportForCoverage, penalizeFeaturesForClassDuplication, true);
                        } else {
                            trainer.setAlpha(power);
                        }
                        FWCModel model = trainer.train();
                        Classifier classifier = new Classifier(model);
                        double[][] scores = classifier.predictScores(validationInstanceFeatures, validationInstanceFeatureValues);
                        if (allScoresForComputingProbabilities != null) {
                            System.arraycopy(scores, 0, allScoresForComputingProbabilities[cIndex], 0, scores.length);
                        }
                        return Utilities.evaluate(scores, validationInstanceClassLabels, classCount, evaluationMetric,
                                ClassificationMethod.FWC);
                    }
                }
            } );
            executorServiceForFoldExecution.execute(tasks[index]);
            index++;


//            System.out.println("Alpha = " + power + ", score = " + s);

//            if (best == -1 || s > bestScore) {
//            	best = power;
//            	bestScore = s;
//            }
        }

        int bestIndex = 0;
        for (int i = 0; i < powerList.length; i ++) {
            double s = tasks[i].get();
//            System.out.println("c = " + cList[i] + ", score = " + s);

            if (best == -1 || s > bestScore) {
                best = powerList[i];
                bestScore = s;
                bestIndex = i;
            }
        }*/

        if (scoreLabelHolderForComputingProbabilities != null) {
//            scoreLabelHolderForComputingProbabilities.features = instanceFeaturesForRefinement;
//            scoreLabelHolderForComputingProbabilities.featureValues = instanceFeatureValuesForRefinement;
            scoreLabelHolderForComputingProbabilities.instanceIDs = instanceIDsForRefinement;
            scoreLabelHolderForComputingProbabilities.labels = labelsForComputingProbabilities;
            scoreLabelHolderForComputingProbabilities.scores = allScoresForComputingProbabilities[bestIndex];
        }
        System.out.println(info + ": Best alpha = " + best + ", score = " + bestScore);
        if (buff != null)
            buff.append("Best weighting function = " + best + ", score = " + bestScore);

        if (GlobalSettings.debugEnabled && GlobalSettings.verbose) {
            System.out.println("Total time alpha selection: " + ((System.currentTimeMillis() - t1) / 1000.0));
        }
        return best;

    }

    public static void sort(double[] c, int[] satelliteData, int numberOfElements) {
        // From http://www.sourcecodesworld.com/articles/java/java-FeatureWeightingClassifier.data-structures/Optimizing_Quicksort.asp
        int i, j, left = 0, right = numberOfElements - 1, stack_pointer = -1;
        int[] stack = new int[128];
        double swap, temp;
        int swapSatellite, tempSatellite;
        while (true) {
            if (right - left <= 7) {
                for (j = left + 1; j <= right; j++) {
                    swap = c[j];
                    swapSatellite = satelliteData[j];
                    i = j - 1;
                    while (i >= left && c[i] > swap /*c[i].compareTo(swap) > 0*/) {
                        c[i + 1] = c[i];
                        satelliteData[i + 1] = satelliteData[i];
                        i--;
                    }
                    c[i + 1] = swap;
                    satelliteData[i + 1] = swapSatellite;
                }
                if (stack_pointer == -1)
                    break;
                right = stack[stack_pointer--];
                left = stack[stack_pointer--];
            } else {
                int median = (left + right) >> 1;
                i = left + 1;
                j = right;
                swap = c[median];
                c[median] = c[i];
                c[i] = swap;
                swapSatellite = satelliteData[median];
                satelliteData[median] = satelliteData[i];
                satelliteData[i] = swapSatellite;
                /* make sure: c[left] <= c[left+1] <= c[right] */
                if (c[left] > c[right]) {
                    swap = c[left];
                    c[left] = c[right];
                    c[right] = swap;
                    swapSatellite = satelliteData[left];
                    satelliteData[left] = satelliteData[right];
                    satelliteData[right] = swapSatellite;
                }
                if (c[i] > c[right]) {
                    swap = c[i];
                    c[i] = c[right];
                    c[right] = swap;
                    swapSatellite = satelliteData[i];
                    satelliteData[i] = satelliteData[right];
                    satelliteData[right] = swapSatellite;
                }
                if (c[left] > c[i]) {
                    swap = c[left];
                    c[left] = c[i];
                    c[i] = swap;
                    swapSatellite = satelliteData[left];
                    satelliteData[left] = satelliteData[i];
                    satelliteData[i] = swapSatellite;
                }
                temp = c[i];
                tempSatellite = satelliteData[i];
                while (true) {
                    do i++; while (c[i] < temp);
                    do j--; while (c[j] > temp);
                    if (j < i)
                        break;
                    swap = c[i];
                    c[i] = c[j];
                    c[j] = swap;
                    swapSatellite = satelliteData[i];
                    satelliteData[i] = satelliteData[j];
                    satelliteData[j] = swapSatellite;
                }
                c[left + 1] = c[j];
                satelliteData[left + 1] = satelliteData[j];
                c[j] = temp;
                satelliteData[j] = tempSatellite;
                if (right - i + 1 >= j - left) {
                    stack[++stack_pointer] = i;
                    stack[++stack_pointer] = right;
                    right = j - 1;
                } else {
                    stack[++stack_pointer] = left;
                    stack[++stack_pointer] = j - 1;
                    left = i;
                }
            }
        }

        // Now sort satellite FeatureWeightingClassifier.data within the same date....
        int start = 0;
        int end = 0;
        while (true) {
            if (satelliteData.length <= start || satelliteData[start] == 0) {
                break;
            }
            end++;
            if (end == satelliteData.length || satelliteData[end] == 0 || c[start] != c[end]) {
                if ((end - start) > 1) {
                    Arrays.sort(satelliteData, start, end); // end is not included as per semantics of this function
                }
                start = end;
            }
        }
    }

    public static double[] calculateClassBalance(int[][] instanceClassLabels, int numClasses) {
        int[] perClassInstanceCount = new int[numClasses];
        for (int[] classes : instanceClassLabels) {
            for (int c : classes) {
                perClassInstanceCount[c - 1]++;
            }
        }
        // Calculate average and max sizes
        double sum = 0, min = Double.POSITIVE_INFINITY, max = 0;
        for (int c : perClassInstanceCount) {
            sum += c;
            if (c > max) {
                max = c;
            }
            if (c < min) {
                min = c;
            }
        }
        double[] out = new double[4];
        out[0] = min;
        out[1] = max;
        out[2] = (sum / numClasses); // Average
        out[3] = (sum / numClasses) / max; // CB
        return out;
    }

    public static int[] scaleDocuments(int[][] trainingInstanceFeatures, double[][] trainingInstanceFeatureValues,
                                       int[][] validationInstanceFeatures, double[][] validationInstanceFeatureValues,
                                       int[][] testInstanceFeatures, double[][] testInstanceFeatureValues,
                                       ScalingMethod documentScalingMethod, int numFeatures, int instanceCount,
                                       int[] featureSupports, int[] featureIndicesOverride) {
        int[] featureSupportsRet = null;
        if (documentScalingMethod != ScalingMethod.NONE) {
            int totalDocs = trainingInstanceFeatures.length;
            if (validationInstanceFeatures != null) totalDocs += validationInstanceFeatures.length;
            if (testInstanceFeatures != null) totalDocs += testInstanceFeatures.length;
            int[][] features = new int[totalDocs][];
            double[][] featureValues = new double[totalDocs][];
            System.arraycopy(trainingInstanceFeatures, 0, features, 0, trainingInstanceFeatures.length);
            System.arraycopy(trainingInstanceFeatureValues, 0, featureValues, 0, trainingInstanceFeatureValues.length);
            if (validationInstanceFeatures != null) {
                System.arraycopy(validationInstanceFeatures, 0, features, trainingInstanceFeatures.length, validationInstanceFeatures.length);
                System.arraycopy(validationInstanceFeatureValues, 0, featureValues, trainingInstanceFeatureValues.length, validationInstanceFeatureValues.length);
            }
            if (testInstanceFeatures != null) {
                System.arraycopy(testInstanceFeatures, 0, features, trainingInstanceFeatures.length + (validationInstanceFeatures == null ? 0 : validationInstanceFeatures.length), testInstanceFeatures.length);
                System.arraycopy(testInstanceFeatureValues, 0, featureValues, trainingInstanceFeatureValues.length + (validationInstanceFeatureValues == null ? 0 : validationInstanceFeatureValues.length), testInstanceFeatureValues.length);
            }
            if (documentScalingMethod == ScalingMethod.TFIDF) {
                featureSupportsRet = convertToTFIDF(features, featureValues, numFeatures, instanceCount, featureSupports, featureIndicesOverride, true);
            } else if (documentScalingMethod == ScalingMethod.BINARY) {
                for (double[] values : featureValues) {
                    Arrays.fill(values, 1);
                }
            } else if (documentScalingMethod == ScalingMethod.L2_NORM) {
                normalizeToDocumentLength(featureValues);
            } else if (documentScalingMethod == ScalingMethod.ZERO_AND_ONE) {
                normalizeBetweenZeroAndOne(featureValues);
            } else if (documentScalingMethod == ScalingMethod.TFIDF_PLUS_ZERO_AND_ONE) {
                // Turned out to be second best on BBC
                featureSupportsRet = convertToTFIDF(features, featureValues, numFeatures, instanceCount, featureSupports, featureIndicesOverride, false);
                normalizeBetweenZeroAndOne(featureValues);
            } else if (documentScalingMethod == ScalingMethod.TFIDF_PLUS_L2_NORM) {
                // Turned out to be most accurate on BBC
                featureSupportsRet = convertToTFIDF(features, featureValues, numFeatures, instanceCount, featureSupports, featureIndicesOverride, false);
                normalizeToDocumentLength(featureValues);
            } else if (documentScalingMethod == ScalingMethod.TWCNB_SCALING) {
                // Rennie's NB (TWCNB)
                featureSupportsRet = convertToTFIDF(features, featureValues, numFeatures, instanceCount, featureSupports, featureIndicesOverride, true);
                // Apply Euclidean norm (Same as L2 norm)...
                normalizeToDocumentLength(featureValues);
            }
        }
        return featureSupportsRet;
    }

    public static Object[] mergeDatasets(int[][] dataset1InstanceFeatures, double[][] dataset1InstanceFeatureValues,
                                         int[][] dataset1InstanceClassLabels, int[] dataset1InstanceIDs,
                                         boolean[] dataset1InstanceNegativeAllowed, int[][] dataset2InstanceFeatures,
                                         double[][] dataset2InstanceFeatureValues, int[][] dataset2InstanceClassLabels,
                                         int[] dataset2InstanceIDs, boolean[] dataset2InstanceNegativeAllowed) {
        int numInstances = dataset1InstanceFeatures.length;
        if (dataset2InstanceFeatures != null) numInstances += dataset2InstanceFeatures.length;
        int[][] mergedInstanceFeatures = new int[numInstances][];
        double[][] mergedInstanceFeatureValues = new double[numInstances][];
        int[][] mergedInstanceClassLabels = new int[numInstances][];
        int[] mergedInstanceIDs = new int[numInstances];
        boolean[] mergedInstanceNegativeAllowed = new boolean[numInstances];
        System.arraycopy(dataset1InstanceFeatures, 0, mergedInstanceFeatures, 0, dataset1InstanceFeatures.length);
        System.arraycopy(dataset1InstanceFeatureValues, 0, mergedInstanceFeatureValues, 0, dataset1InstanceFeatureValues.length);
        System.arraycopy(dataset1InstanceClassLabels, 0, mergedInstanceClassLabels, 0, dataset1InstanceClassLabels.length);
        System.arraycopy(dataset1InstanceIDs, 0, mergedInstanceIDs, 0, dataset1InstanceIDs.length);
        System.arraycopy(dataset1InstanceNegativeAllowed, 0, mergedInstanceNegativeAllowed, 0, dataset1InstanceNegativeAllowed.length);
        if (dataset2InstanceFeatures != null) {
            System.arraycopy(dataset2InstanceFeatures, 0, mergedInstanceFeatures, dataset1InstanceFeatures.length, dataset2InstanceFeatures.length);
            System.arraycopy(dataset2InstanceFeatureValues, 0, mergedInstanceFeatureValues, dataset1InstanceFeatureValues.length, dataset2InstanceFeatureValues.length);
            System.arraycopy(dataset2InstanceClassLabels, 0, mergedInstanceClassLabels, dataset1InstanceClassLabels.length, dataset2InstanceClassLabels.length);
            System.arraycopy(dataset2InstanceIDs, 0, mergedInstanceIDs, dataset1InstanceIDs.length, dataset2InstanceIDs.length);
            System.arraycopy(dataset2InstanceNegativeAllowed, 0, mergedInstanceNegativeAllowed, dataset1InstanceNegativeAllowed.length, dataset2InstanceNegativeAllowed.length);
        }

        return new Object[]{mergedInstanceFeatures, mergedInstanceFeatureValues, mergedInstanceClassLabels,
                mergedInstanceIDs, mergedInstanceNegativeAllowed};
    }


    public static void shuffleArrayElements(String[] array) {
        if (array == null) return;
        Random r = new Random(100000);
        int numInstances = array.length;
        for (int i = 0; i < numInstances; i++) {
            int index1 = (int) (r.nextDouble() * numInstances);
            int index2 = (int) (r.nextDouble() * numInstances);
            if (index1 != index2) {
                // Swap instances at the two indices
                String tempName = array[index1];
                array[index1] = array[index2];
                array[index2] = tempName;
            }
        }
    }

}
