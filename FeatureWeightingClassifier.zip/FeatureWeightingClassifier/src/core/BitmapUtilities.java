package core;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class BitmapUtilities {

    public static int[] valueToBitCount = new int[256];
    public static long[] oneBitHigh = new long[64];

    static {
        for (int i = 1; i < 256; i++) {
            int bit1 = (i & 1) > 0 ? 1 : 0;
            int bit2 = (i & 2) > 0 ? 1 : 0;
            int bit3 = (i & 4) > 0 ? 1 : 0;
            int bit4 = (i & 8) > 0 ? 1 : 0;
            int bit5 = (i & 16) > 0 ? 1 : 0;
            int bit6 = (i & 32) > 0 ? 1 : 0;
            int bit7 = (i & 64) > 0 ? 1 : 0;
            int bit8 = (i & 128) > 0 ? 1 : 0;
            valueToBitCount[i] = bit1 + bit2 + bit3 + bit4 + bit5 + bit6 + bit7 + bit8;
        }

        for (int i = 0; i < 64; i++) {
            oneBitHigh[i] = (long) 1 << (long) i;
        }
    }

    public static int countBits(long value) {
        int count = 0;
        count += valueToBitCount[((((int) value) << 24)) >>> 24];
        count += valueToBitCount[((((int) value >>> 8) << 24)) >>> 24];
        count += valueToBitCount[((((int) value >>> 16) << 24)) >>> 24];
        count += valueToBitCount[((((int) value >>> 24) << 24)) >>> 24];
        count += valueToBitCount[((((int) (value >>> 32)) << 24)) >>> 24];
        count += valueToBitCount[((((int) (value >>> 40)) << 24)) >>> 24];
        count += valueToBitCount[((((int) (value >>> 48)) << 24)) >>> 24];
        count += valueToBitCount[((((int) (value >>> 56)) << 24)) >>> 24];
        return count;
    }

    public static long[] ANDTwoBitmaps(long[] bitmap1, long[] bitmap2) {
        long[] out = new long[bitmap1.length];
        for (int i = 0; i < bitmap1.length; i++) {
            out[i] = bitmap1[i] & bitmap2[i];
        }
        return out;
    }

    public static int countBitsInArray(long[] array) {
        int bitCount = 0;
        for (int j = 0; j < array.length; j++) {
            bitCount += countBits(array[j]);
        }
        return bitCount;
    }

    static void displayAllBits(long data) {
        System.out.println("Displaying...");
        for (int i = 0; i < 64; i++) {
            System.out.print((data & oneBitHigh[i]) == 0 ? 0 : 1);
        }
    }

}
