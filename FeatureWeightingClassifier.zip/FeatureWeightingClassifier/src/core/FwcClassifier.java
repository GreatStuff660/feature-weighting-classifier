package core;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class FwcClassifier {

    private boolean allowSparseOptimization;
    private double alpha;
    public int[] predictedLabels;
    public double[] predictedLabelsDouble;
    WeightingScheme weightingScheme;
    WeightAdjustmentScheme weightAdjustmentScheme;
    boolean penalizeFeaturesForClassDuplication;
    public double f1Micro;
    public double accuracy;
    public double f1Macro;


    public FwcClassifier() {
        this.weightAdjustmentScheme = core.WeightAdjustmentScheme.CLASS_SUPPORT;
        this.weightingScheme = core.WeightingScheme.INFORMATION_GAIN;
        this.allowSparseOptimization = true;
        this.weightingScheme = WeightingScheme.INFORMATION_GAIN;
        this.penalizeFeaturesForClassDuplication = false;
    }



    public double getBestAlpha(int classCount, int featureCount, int[][] instanceFeatures,
                               double[][] instanceFeatureValues,
                               int[][] classLabels, int[] instanceIDS) throws Exception {
        ExecutorService executor = Executors.newCachedThreadPool();
        int noOfFolds = 10;
        boolean[] negativeAllowed = new boolean[instanceIDS.length];
        alpha = core.Utilities.autoSelectAlpha(classCount, featureCount, instanceFeatures, instanceFeatureValues,
                classLabels, instanceIDS, negativeAllowed,
                null, null, null, null, null, weightingScheme, weightAdjustmentScheme,
                penalizeFeaturesForClassDuplication, noOfFolds, EvaluationMetric.ACCURACY, new StringBuffer(),
                executor, null, "", false);
        executor.shutdown();
        return alpha;
    }


    public FWCModel trainFWC(int classCount, int featureCount, int[][] instanceFeatures,
                             double[][] instanceFeatureValues,
                             int[][] classLabels, int[] instanceIDS, double alpha) throws Exception {

        Trainer trainer = new Trainer(classCount, featureCount, instanceFeatures, instanceFeatureValues, classLabels,
                weightingScheme, weightAdjustmentScheme, penalizeFeaturesForClassDuplication, allowSparseOptimization);

        FWCModel model = trainer.train(alpha);
        return model;
    }


    public void predictFWC(core.FWCModel model, int[][] testInstanceFeatures,
                           double[][] testInstanceFeatureValues, int[][] testInstanceClassLabels, int[] instanceIDs, int numClasses) {
        core.Classifier classifier = new core.Classifier(model);
        double[][] scores = classifier.predictScores(testInstanceFeatures, testInstanceFeatureValues);
        this.predictedLabels = getPredictionByMaxScoreAlt(scores);
        this.predictedLabelsDouble = new double[predictedLabels.length];
        for (int i = 0; i < predictedLabels.length; i++) {
            predictedLabelsDouble[i] = (double) predictedLabels[i];
        }


        f1Micro = Utilities.evaluate(scores, testInstanceClassLabels, numClasses, EvaluationMetric.F1MICRO);

        accuracy = Utilities.evaluate(scores, testInstanceClassLabels, numClasses, EvaluationMetric.ACCURACY);

        f1Macro = Utilities.evaluate(scores, testInstanceClassLabels, numClasses, EvaluationMetric.F1MACRO);

    }

    private int[][] getLabelsFromScores(double[][] scores){
        int[][] predictedLabels = new int[scores.length][];
        for(int i = 0;i<scores.length;i++){
            ArrayList<Integer> pred = new ArrayList<Integer>();
            for(int j =0;j<scores[i].length;j++){
                if(scores[i][j] > 0) pred.add(j+1);
            }
            Integer[] instPred = pred.toArray(new Integer[pred.size()]);
            int[] instp = new int[instPred.length];
            for(int k=0;k<instPred.length;k++) instp[k] = instPred[k];
            predictedLabels[i] = instp;
        }

        return predictedLabels;
    }


    public int[] getPredictionByMaxScore(double[][] scores) {
        int[] predictedLabels = new int[scores.length];
        for (int i = 0; i < scores.length; i++) {
            predictedLabels[i] = (core.Utilities.getIndexWithMaxScore(scores[i], true) + 1);//%2 + 1;
        }
        return predictedLabels;
    }

    public int[] getPredictionByMaxScoreAlt(double[][] scores) {
        int[] predictedLabels = new int[scores.length];
        for (int i = 0; i < scores.length; i++) {
            predictedLabels[i] = (core.Utilities.getIndexWithMaxScore(scores[i], true)) == 0 ? 1 : -1;

        }
        return predictedLabels;
    }
}