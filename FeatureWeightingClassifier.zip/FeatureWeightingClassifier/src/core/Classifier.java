package core;

import core.configuration.GlobalSettings;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class Classifier {

    FWCModel model;

    public Classifier(FWCModel model) {
        this.model = model;
    }

    public double[][] predictScores(int[][] instanceFeatures, double[][] instanceFeatureValues) {
        long t1 = System.currentTimeMillis();
        int classCount = model.weights.length - 1;
        double[][] scores = new double[instanceFeatures.length][classCount];
        long t2 = System.currentTimeMillis();
        // Process each instance
        for (int i = 0; i < instanceFeatures.length; i++) {
            // Process all features for this instance
            for (int f = 0; f < instanceFeatures[i].length; f++) {
                if (instanceFeatureValues[i][f] != 0) {
                    // Each feature may contribute to each class score...
                    int start = model.applicableClassesForEachFeature == null ? 1 : 0;
                    int end = model.applicableClassesForEachFeature == null ? classCount : model.applicableClassesForEachFeature[instanceFeatures[i][f]].length - 1;
                    for (int j = start; j <= end; j++) {
                        int c = model.applicableClassesForEachFeature == null ? j : model.applicableClassesForEachFeature[instanceFeatures[i][f]][j];
                        scores[i][c - 1] += (instanceFeatureValues[i][f] * model.weights[c][instanceFeatures[i][f]]);
                    }
                }
            }
        }
        long t3 = System.currentTimeMillis();
        if (GlobalSettings.debugEnabled && GlobalSettings.verbose) {
            System.out.println("Classifier time1: " + ((t2 - t1) / 1000.0) + ", time2: " + ((t3 - t2) / 1000.0) + ", total: " + ((t3 - t1) / 1000.0));
        }
        return scores;
    }

}
