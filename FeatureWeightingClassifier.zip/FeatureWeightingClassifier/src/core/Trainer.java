package core;

import core.configuration.GlobalSettings;

//import FeatureWeightingClassifier.configuration.GlobalSettings;

import java.util.Arrays;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class Trainer {

    int classCount;
    int featureCount;
    int[][] instanceFeatures;
    double[][] instanceFeatureValues;
    int[][] instanceClassLabels;
    WeightingScheme weightingScheme;
    WeightAdjustmentScheme weightAdjustmentScheme;
    int[][] featureSupports;
    boolean[] featureSelected;
    boolean[][] featureSelectedPerClass;
    boolean[] isFeatureOutlier;
    int[] featureClassCount;
    private final static double LOG_2 = Math.log(2);
    boolean penalizeFeaturesForClassDuplication;
    int totalFeaturesConsideredForSelection = 0;
    private double[][] tempBuffer = null;
    private int[][] applicableClassesForEachFeature = null;
    private double[] entropyAllAbsentCacheForSparseData;

    /**
     * Multi-label instances are supported
     * Class labels and feature IDs are assumed to be one-based
     *
     * @param classCount
     * @param featureCount
     * @param instanceFeatures
     * @param instanceFeatureValues
     * @param instanceClassLabels
     * @param weightingScheme
     * @param weightAdjustmentScheme
     * @param penalizeFeaturesForClassDuplication
     * @param allowSparseOptimization
     * @throws Exception
     */
    public Trainer(int classCount, int featureCount, int[][] instanceFeatures, double[][] instanceFeatureValues,
                   int[][] instanceClassLabels, WeightingScheme weightingScheme,
                   WeightAdjustmentScheme weightAdjustmentScheme, boolean penalizeFeaturesForClassDuplication,
                   boolean allowSparseOptimization) {
        this.classCount = classCount;
        this.featureCount = featureCount;
        this.instanceFeatures = instanceFeatures;
        this.instanceFeatureValues = instanceFeatureValues;
        this.instanceClassLabels = instanceClassLabels;
        this.weightingScheme = weightingScheme;
        this.weightAdjustmentScheme = weightAdjustmentScheme;
        this.penalizeFeaturesForClassDuplication = penalizeFeaturesForClassDuplication;
        calculateGlobalAndClassSupports(allowSparseOptimization);
        featureSelected = new boolean[featureCount + 1];
        Arrays.fill(featureSelected, true);
    }

    public FWCModel train(double alpha) throws Exception {
        return trainModel(alpha);
    }

    private void calculateGlobalAndClassSupports(boolean allowSparseOptimization) {
        // Row 1 contains global supports for all features. Rows 1-classCount contains class supports for all features
        featureSupports = new int[classCount + 1][featureCount + 1];
        featureClassCount = new int[featureCount + 1];

        long[][] featureClassBimap = null;
        if (allowSparseOptimization) {
            // Determine if the provided FeatureWeightingClassifier.data is sparse
            int nnz = 0;
            for (int i = 0; i < instanceFeatures.length; i++) {
                nnz += instanceFeatures[i].length;
            }
            double density = (((double) nnz)) / (((long) featureCount) * instanceFeatures.length);
            if (density < 0.3) {
                featureClassBimap = new long[featureCount + 1][(int) Math.ceil((classCount + 1) / 64.0)];
                entropyAllAbsentCacheForSparseData = new double[instanceFeatures.length];
                Arrays.fill(entropyAllAbsentCacheForSparseData, Double.NEGATIVE_INFINITY);
            }
        }

        for (int i = 0; i < instanceFeatures.length; i++) {
            // First update the overall support for all applicable classes
            for (int c = 0; c < instanceClassLabels[i].length; c++) {
                featureSupports[instanceClassLabels[i][c]][0]++;
            }
            // Now process all features
            for (int f = 0; f < instanceFeatures[i].length; f++) {
                // Update global feature support...
                if (instanceFeatureValues[i][f] != 0) {
                    int featureIndex = instanceFeatures[i][f];
                    featureSupports[0][featureIndex]++;
                    // Finally update the feature support for all applicable classes
                    for (int c = 0; c < instanceClassLabels[i].length; c++) {
                        int cls = instanceClassLabels[i][c];
                        if (featureSupports[cls][featureIndex] == 0) {
                            featureClassCount[featureIndex]++;
                        }
                        featureSupports[cls][featureIndex]++;
                        if (featureClassBimap != null) {
                            int mod = cls % 64;
                            featureClassBimap[featureIndex][cls / 64] |= BitmapUtilities.oneBitHigh[mod];
                        }
                    }
                }
            }
        }
        if (featureClassBimap != null) {
            // Generate the list of applicable classes for each feature
            applicableClassesForEachFeature = new int[featureCount + 1][];
            for (int i = 0; i < applicableClassesForEachFeature.length; i++) {
                int numClassesForThisFeature = BitmapUtilities.countBitsInArray(featureClassBimap[i]);
                applicableClassesForEachFeature[i] = new int[numClassesForThisFeature];
                int index = 0;
                for (int j = 0; j < featureClassBimap[i].length; j++) {
                    // If at-least one bit is set
                    if (featureClassBimap[i][j] != 0) {
                        for (int k = 0; k < 64; k++) {
                            if ((featureClassBimap[i][j] & BitmapUtilities.oneBitHigh[k]) != 0) {
                                applicableClassesForEachFeature[i][index++] = ((j * 64) + k);
                            }
                        }
                    }
                }
            }
        }
    }

    private double[] calculateInformationGainForAllFeatures() {
        double[] featureSignificanceScores = new double[featureCount + 1];
        // Calculate S
        double S = 0;

        for (int i = 1; i < featureSupports.length; i++) {
            if (featureSupports[i][0] > 0) {
                S += calcEntropy(featureSupports[i][0], instanceClassLabels.length);
            }
        }

        for (int feature = 1; feature <= featureCount; feature++) {
            if (featureSupports[0][feature] > 0) {
                double infoGain = getAttributeInformationGain(feature, S);
                if (Double.isNaN(infoGain) || Double.isInfinite(infoGain)) {
                    System.out.println("Big problem!");
                }
                if (infoGain < -0.0001 || infoGain > 1.0001) {
                    System.out.println("Info gain out of range!");
                }
                featureSignificanceScores[feature] = infoGain;
            }
        }
        return featureSignificanceScores;
    }

    static double calcEntropy(double no, double total) {
        return ((-(no / total)) * (Math.log(no / total) / LOG_2));
    }

    private double getAttributeInformationGain(int feature, double S) {
        double noOfInstancesWithThisAttribute = featureSupports[0][feature];
        double entropyAllAbsent = applicableClassesForEachFeature == null ? 0 : getEntropyAllAbsent(featureSupports[0][feature]);

        double entrPresent = 0;
        double entrAbsent = 0;
        int start = applicableClassesForEachFeature == null ? 1 : 0;
        int end = applicableClassesForEachFeature == null ? classCount : applicableClassesForEachFeature[feature].length - 1;

        for (int i = start; i <= end; i++) {
            int cls = applicableClassesForEachFeature == null ? i : applicableClassesForEachFeature[feature][i];
            int val = featureSupports[cls][feature];
            if (val > 0) {
                entrPresent += calcEntropy(val, noOfInstancesWithThisAttribute);
            }
            int countAbsent = featureSupports[cls][0] - val;
            if (countAbsent > 0) {
                entrAbsent += calcEntropy(countAbsent, (instanceClassLabels.length - noOfInstancesWithThisAttribute));
            }
            int numInstancesWithoutAttribute = instanceClassLabels.length - (int) noOfInstancesWithThisAttribute;
            if (applicableClassesForEachFeature != null && numInstancesWithoutAttribute > 0) {
                entrAbsent -= calcEntropy(featureSupports[cls][0], numInstancesWithoutAttribute);
            }
        }

        if (applicableClassesForEachFeature != null) {
            entrAbsent += entropyAllAbsent;
        }

//        System.out.println(feature + "," + entrAbsent);

        double totalEntropy = ((noOfInstancesWithThisAttribute / instanceClassLabels.length) * entrPresent) +
                (((instanceClassLabels.length - noOfInstancesWithThisAttribute) / instanceClassLabels.length) * entrAbsent);
        return S - totalEntropy;
    }

    private double[] calculateChiSquareForAllFeatures() {
        double[] featureSignificanceScores = new double[featureCount + 1];
        int totalNumberOfInstances = instanceClassLabels.length;
        for (int j = 1; j <= featureCount; j++) {
            if (featureSupports[0][j] > 0) {
                double score = 0;
                for (int i = 1; i <= classCount; i++) {
                    if (featureSupports[i][j] > 0) {
                        double pos = featureSupports[i][0];
                        double neg = (totalNumberOfInstances - pos);
                        double tp = featureSupports[i][j];
                        double fp = (featureSupports[0][j] - featureSupports[i][j]);
                        double fn = (pos - tp);
                        double tn = (neg - fp);
                        double pPos = pos / (double) totalNumberOfInstances;
                        double expect1 = ((tp + fp) * pPos);
                        double expect2 = ((fn + tn) * pPos);
                        score += ((((tp - expect1) * (tp - expect1)) / expect1) + (((fn - expect2) * (fn - expect2)) / expect2));
                    }
                }
                featureSignificanceScores[j] = score;
            }
        }

        return featureSignificanceScores;
    }

    private double[][] calculateOneVsRestInformationGainForAllFeatures(int classID) {

        double[][] perClassIGScores = classID == -1 ? new double[classCount][featureCount + 1] : tempBuffer;
        int datasetSize = instanceClassLabels.length;

        int startClass = classID == -1 ? 1 : classID;
        int endClass = classID == -1 ? classCount : classID;

        for (int feature = 1; feature <= featureCount; feature++) {
            int noOfInstancesWithThisAttribute = featureSupports[0][feature];
            if (noOfInstancesWithThisAttribute > 0) {
//                for (int i = 1; i <= classCount; i ++) {
                for (int i = startClass; i <= endClass; i++) {

                    double entrPresent = 0;
                    double entrAbsent = 0;

                    int featureCountInPositiveClass = featureSupports[i][feature];

                    if (featureCountInPositiveClass > 0) {
                        int sizeOfPositiveClass = featureSupports[i][0];
                        int sizeOfNegativeClass = datasetSize - sizeOfPositiveClass;

                        // Calculate S
                        double S = calcEntropy(sizeOfPositiveClass, datasetSize);
                        S += calcEntropy(sizeOfNegativeClass, datasetSize);

                        if (featureCountInPositiveClass > 0) {
                            entrPresent += calcEntropy(featureCountInPositiveClass, noOfInstancesWithThisAttribute);
                        }


                        int countAbsentInPositiveClass = sizeOfPositiveClass - featureCountInPositiveClass;
                        if (countAbsentInPositiveClass > 0) {
                            entrAbsent += calcEntropy(countAbsentInPositiveClass, (datasetSize - noOfInstancesWithThisAttribute));
                        }

                        int featureCountInNegativeClass = noOfInstancesWithThisAttribute - featureCountInPositiveClass;
                        if (featureCountInNegativeClass > 0) {
                            entrPresent += calcEntropy(featureCountInNegativeClass, noOfInstancesWithThisAttribute);
                        }

                        int countAbsentInNegativeClass = sizeOfNegativeClass - featureCountInNegativeClass;
                        if (countAbsentInNegativeClass > 0) {
                            entrAbsent += calcEntropy(countAbsentInNegativeClass, (datasetSize - noOfInstancesWithThisAttribute));
                        }


                        double totalEntropy = ((noOfInstancesWithThisAttribute / ((double) datasetSize)) * entrPresent) +
                                (((datasetSize - noOfInstancesWithThisAttribute) / ((double) datasetSize)) * entrAbsent);
                        if (classID == -1) {
                            perClassIGScores[i - 1][feature] = S - totalEntropy;
                        } else {
                            perClassIGScores[0][feature] = S - totalEntropy;
                        }
                    }

                    ////////////////////


                    /*perClassIGScores[i - 1][feature] = Utilities.getBNSValue(featureSupports[i][0],
                            instanceClassLabels.length - featureSupports[i][0], featureSupports[i][feature],
                            featureSupports[0][feature] - featureSupports[i][feature]);*/
                }
            }
        }

        return perClassIGScores;
    }

    private FWCModel trainModel(double alpha) {

        long t1 = System.currentTimeMillis();
        double[] globalSignificanceScores = null;
        double[][] oneVsRestSignificanceScores = null;
        if (weightingScheme == WeightingScheme.INFORMATION_GAIN) {
            globalSignificanceScores = calculateInformationGainForAllFeatures();
        } else if (weightingScheme == WeightingScheme.INFORMATION_GAIN_ONE_VS_REST) {
            oneVsRestSignificanceScores = calculateOneVsRestInformationGainForAllFeatures(-1);
        } else if (weightingScheme == WeightingScheme.CHI_SQUARE) {
            globalSignificanceScores = calculateChiSquareForAllFeatures();
        }

        long t2 = System.currentTimeMillis();
        double[][] weights = new double[classCount + 1][featureCount + 1];
        long t3 = System.currentTimeMillis();
        double instanceCount = instanceClassLabels.length;
        for (int f = 0; f < featureSupports[0].length; f++) {
            if (featureSupports[0][f] > 0 && featureSelected[f]) {
                // If this feature was used in any instance, and was selected
                // First assign the global weight (for reference only, not used for classification)
                double featureWeight = 0;
                if (weightingScheme == WeightingScheme.GLOBAL_SUPPORT) {
                    featureWeight = featureSupports[0][f] / instanceCount;
                } else if (weightingScheme == WeightingScheme.INFORMATION_GAIN || weightingScheme == WeightingScheme.CHI_SQUARE) {
                    featureWeight = globalSignificanceScores[f];
                }
                weights[0][f] = featureWeight;
                int start = applicableClassesForEachFeature == null ? 1 : 0;
                int end = applicableClassesForEachFeature == null ? classCount : applicableClassesForEachFeature[f].length - 1;
//                for (int c = 1; c <= classCount; c ++) {
                for (int c = start; c <= end; c++) {
                    int cls = applicableClassesForEachFeature == null ? c : applicableClassesForEachFeature[f][c];
                    if (weightingScheme == WeightingScheme.INFORMATION_GAIN_ONE_VS_REST) {
                        featureWeight = oneVsRestSignificanceScores[cls - 1][f];
                    }
                    // If this feature was used in this class
                    weights[cls][f] = getAdjustedClassWeightForFeature(f, featureWeight, cls, alpha);
                    if (Double.isNaN(weights[cls][f])) {
                        System.out.println("NaN");
                    }
                }
            }
        }
        if (GlobalSettings.debugEnabled && GlobalSettings.verbose) {
            long t4 = System.currentTimeMillis();
            System.out.println("Trainer Time1: " + ((t2 - t1) / 1000.0) + ", time2: " + ((t3 - t2) / 1000.0) + ", time3: " + ((t4 - t3) / 1000.0) + ", total: " + ((t4 - t1) / 1000.0));
        }
        return new FWCModel(weights, applicableClassesForEachFeature);
    }

    private double getAdjustedClassWeightForFeature(int feature, double featureGlobalWeight, int classID, double alpha) {
        double adjustmentWeight = 0;
        if (weightAdjustmentScheme == WeightAdjustmentScheme.CLASS_SUPPORT) {
            if (featureSupports[classID][0] == 0) return 0;
            adjustmentWeight = featureSupports[classID][feature] / ((double) featureSupports[classID][0]);
        }

        double adjustedWeight = featureGlobalWeight * Math.pow(adjustmentWeight, alpha);

        if (penalizeFeaturesForClassDuplication) {
            adjustedWeight /= featureClassCount[feature];
        }

        return adjustedWeight;
    }

    public double[] genFeatureSignificanceStats(FWCModel model) {
        double[] res = new double[4];
        double total = 0;
        int count = featureCount;
        for (double score : model.weights[0]) {
            total += score;
        }
        double mean = total / count;
        // Now find standard deviation
        total = 0;
        for (double score : model.weights[0]) {
            total += ((score - mean) * (score - mean));
        }
        double standardDeviation = Math.sqrt(total / count);
        double cutOffScore = (mean + (standardDeviation * 3));
        int outlierCount = 0;
        isFeatureOutlier = new boolean[featureSelected.length];
        for (int i = 0; i < model.weights[0].length; i++) {
            if (model.weights[0][i] >= cutOffScore) {
                isFeatureOutlier[i] = true;
                outlierCount++;
            }
        }

        model.isFeatureOutlier = isFeatureOutlier;

        // Calculate median IG
        double median = 0;
        if (model.weights[0].length % 2.0 == 0) {
            // Average
            median = (model.weights[0][(int) (model.weights[0].length / 2.0) - 1] + model.weights[0][(int) (model.weights[0].length / 2.0)]) / 2.0;
        } else {
            median = model.weights[0][(int) (model.weights[0].length / 2.0)];
        }

        res[0] = mean;
        res[1] = outlierCount;
        res[2] = outlierCount / (double) count;
        res[3] = median;
        return res;
    }

    public boolean[] getFeatureSelectionStatus() {
        return featureSelected;
    }

    public boolean[][] getFeatureSelectionStatusPerClass() {
        return featureSelectedPerClass;
    }

    public int getTotalFeaturesConsideredForSelection() {
        return totalFeaturesConsideredForSelection;
    }

    public boolean featureUsed(int featureID) {
        return featureSupports[0][featureID] > 0;
    }

    /**
     * Computes entropyAbsent of a feature with support = "featureSupport" and uses a small cache. This helps speed up the global information gain computation on sparse FeatureWeightingClassifier.data
     *
     * @param featureSupport
     * @return
     */
    private double getEntropyAllAbsent(int featureSupport) {
        if (entropyAllAbsentCacheForSparseData[featureSupport - 1] != Double.NEGATIVE_INFINITY) {
            return entropyAllAbsentCacheForSparseData[featureSupport - 1];
        }

        double out = 0;
        for (int i = 1; i <= classCount; i++) {
            int numInstancesWithoutFeature = instanceClassLabels.length - featureSupport;
            if (featureSupports[i][0] > 0 && numInstancesWithoutFeature > 0) {
                out += calcEntropy(featureSupports[i][0], numInstancesWithoutFeature);
            }
        }

        entropyAllAbsentCacheForSparseData[featureSupport - 1] = out;
        return out;
    }
}
