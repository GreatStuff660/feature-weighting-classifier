package core.utilities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.StringTokenizer;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class MtxToClutoMatrix {
    public static void main(String[] s) {
        if (s.length < 4) {
            System.out.println("Please provide parameters in the following order: inputMtxFile inputTermsFile inputDocsFile outputClutoMatrixFilePrefix");
            System.exit(0);
        }

        try {
            BufferedReader inputMtxFile = new BufferedReader(new FileReader(s[0]));
            BufferedReader inputTermsFile = new BufferedReader(new FileReader(s[1]));
            BufferedReader inputClassesFile = new BufferedReader(new FileReader(s[2]));
            BufferedWriter mat = new BufferedWriter(new FileWriter(s[3] + ".mat"));
            BufferedWriter rclass = new BufferedWriter(new FileWriter(s[3] + ".mat.rclass"));
            BufferedWriter clabel = new BufferedWriter(new FileWriter(s[3] + ".mat.clabel"));

            int numInstances = -1;
            int numFeatures = 0;
            int nnz = 0;
            int[][] instanceFeatures = null;
            int[][] instanceFeatureValues = null;
            int[] curIndexForInstance = null;

            // Read the matrix
            String str = null;
            while ((str = inputMtxFile.readLine()) != null) {
                if (str.startsWith("%")) continue;
                StringTokenizer tok = new StringTokenizer(str, " ");
                int val1 = Integer.parseInt(tok.nextToken());
                int val2 = Integer.parseInt(tok.nextToken());
                int val3 = (int) Double.parseDouble(tok.nextToken());
                if (numInstances == -1) {
                    numFeatures = val1;
                    numInstances = val2;
                    nnz = val3;
                    instanceFeatures = new int[numInstances][numFeatures];
                    instanceFeatureValues = new int[numInstances][numFeatures];
                    curIndexForInstance = new int[numInstances];
                } else {
                    instanceFeatures[val2 - 1][curIndexForInstance[val2 - 1]] = val1;
                    instanceFeatureValues[val2 - 1][curIndexForInstance[val2 - 1]] = val3;
                    curIndexForInstance[val2 - 1]++;
                }
            }
            // Write the matrix
            mat.write(numInstances + " " + numFeatures + " " + nnz + "\n");
            for (int i = 0; i < instanceFeatures.length; i++) {
                for (int j = 0; j < instanceFeatures[i].length; j++) {
                    if (instanceFeatures[i][j] == 0) break;
                    mat.write(instanceFeatures[i][j] + " " + instanceFeatureValues[i][j] + " ");
                }
                mat.write("\n");
            }

            // Read and write the classes
            while ((str = inputClassesFile.readLine()) != null) {
                if (str.startsWith("%")) continue;
                StringTokenizer tok = new StringTokenizer(str, " ");
                int val1 = Integer.parseInt(tok.nextToken());
                int val2 = Integer.parseInt(tok.nextToken());
                rclass.write(val2 + "\n");
            }

            // Read and write the column labels
            while ((str = inputTermsFile.readLine()) != null) {
                if (str.startsWith("%")) continue;
                clabel.write(str + "\n");
            }

            inputMtxFile.close();
            inputTermsFile.close();
            inputClassesFile.close();

            mat.close();
            rclass.close();
            clabel.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
