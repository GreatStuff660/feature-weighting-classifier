package core.utilities;

import java.util.ArrayList;

/**
 Copyright 2011 by Hassan Malik, Dmitriy Fradkin and Fabian Moerchen
 This file is part of Feature Weighting Classifier (FWC).

    This program is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class NodeScoreList implements Comparable<NodeScoreList> {
    public NodeScoreList parent;
    public int nodeID;
    public double nodeScore;
    public boolean isLeaf;
    ArrayList<NodeScoreList> next = new ArrayList<NodeScoreList>();
    public boolean refinementClass;
    public double probability;

    public NodeScoreList(NodeScoreList parent, int nodeID, double nodeScore, boolean leaf, boolean refinementClass,
                         double probability) {
        this.parent = parent;
        this.nodeID = nodeID;
        this.nodeScore = nodeScore;
        this.isLeaf = leaf;
        this.refinementClass = refinementClass;
        this.probability = probability;
    }

    public int compareTo(NodeScoreList o) {
        if (o.nodeScore > nodeScore) {
            return -1;
        } else {
            return 1;
        }
    }

}
