This is a reference implementation of the Feature Weighting Classifier (FWC). Please cite:

Malik, H.H., Fradkin, D., and Moerchen, F.,
"Single pass text classification by direct feature weighting",
In Knowledge and Information Systems, Volume 28 (1), July 2011.

Classes TestFWC_Cluto_LibSVM and TestFWC provide sample code.

For example, to apply FWC to a dataset in cluto or LibSVM format: 

java -jar FWC.jar clutoMatFilePathOrLibSVMFilePath

Cluto datasets can be downloaded from http://glaros.dtc.umn.edu/gkhome/cluto/cluto/download